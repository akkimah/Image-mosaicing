img1 = imread('m0.jpg');
img2 = imread('m1.jpg');
%imshow(img1);
%cpselect(img2,img1);
%arr_src=[1295,937,2479,969,1647,1473,2419,1619];
%arr_dest=[95,1361,2051,103,985,1585,2393,905];
x0=1200; y0=937;
x1=2497; y1=969;
x2=1643; y2=1473;
x3=2419; y3=1619;

xp0=95; yp0=1361;
xp1=2051; yp1=103;
xp2=985; yp2=1585;
xp3=2393; yp3=905;
H=homography(x0,y0, x1,y1, x2,y2, x3,y3, xp0,yp0, xp1,yp1, xp2,yp2,xp3,yp3);
h=inv(H);

[m,n]=size(img2);
%C = corner(img2);
xmin = 1;
xmax = abs(size(img2,2));
ymin = 1;
ymax = abs(size(img2,1));

Srcpoints=[1 1;1 1664;1664 1;1664 2496];
projected_point=[1 1 1] * H;
l1=projected_point(1,1)/projected_point(1,3);
m1=projected_point(1,2)/projected_point(1,3);

projected_point=[1 1664 1] * H;
l2=projected_point(1,1)/projected_point(1,3);
m2=projected_point(1,2)/projected_point(1,3);

projected_point=[1664 1 1] * H;
l3=projected_point(1,1)/projected_point(1,3);
m3=projected_point(1,2)/projected_point(1,3);

projected_point=[1664 2496 1] * H;
l4=projected_point(1,1)/projected_point(1,3);
m4=projected_point(1,2)/projected_point(1,3);

corners=[l1 m1;l2 m2;l3 m3;l4 m4];

MAX_X=corners(1,1);


for i=1:4
if MAX_X<= corners(i,1)
MAX_X=corners(i,1);
end
end

disp(MAX_X)


MAX_Y=corners(1,2);
for i=1:4
if MAX_Y<= corners(i,2)
MAX_Y=corners(i,2);
end
end

disp(MAX_Y)


MIN_X=corners(1,1);

for i=1:4
if MIN_X>= corners(i,1)
MIN_X=corners(i,1);
end
end

disp(MIN_X)




MIN_Y=corners(1,2);
for i=1:4
if MIN_Y>= corners(i,2)
MIN_Y=corners(i,2);
end
end

disp(MIN_Y)


    offset_y=abs(MIN_Y);


    offset_x=abs(MIN_X);


height_max=MAX_Y-MIN_Y;
width_max=MAX_X-MIN_X;

%height_new=height_max+offset_y;
%width_new=width_max+offset_x;
Opimg = zeros(round(height_max),4992);
%hh = height_new;
%ww = width_new;
img1=im2double(img1);
 for i=1:1664
    for j=1:2496
    red = img1(i,j,1);
    green = img1(i,j,2);
    blue = img1(i,j,3);
   
        Opimg(i+1768,j,1)=red;
        Opimg(i+1768,j,2)=green;
        Opimg(i+1768,j,3)=blue;
        %Opimg(i+1768,j,d) = img1(i,j,d);
        
    end
 end
%Opimg=uint8(Opimg);
%figure,imshow(Opimg);




H=[0.000584833983883437,-0.000389757434320398,-3.34430919209875e-10;9.26818829249812e-05,0.000364768269307820,-7.62666181308973e-08;-0.751372686029558,0.659877439854720,0.000464189653357783];

h = inv(H);
I=imread('m1.jpg');
[m,n]=size(I);
temp = zeros(3729,3428);
%imshow('m1.jpg');
I1=im2double(I);
for i=1:1664
for j=1:2496
v1 = [j ,i, 1];
v2 = v1*h;
vx = v2(1,1)/v2(1,3);
vy = v2(1,2)/v2(1,3);
vx=round(vx);
vy=round(vy);
if(vx>=1 && vy>=1 && vx<=size(temp,1) && vy<=size(temp,2))

%if(v3(1,1) <0 || v3(2,1)<0 || v3(3,1)<0)
 %  continue;
%else     
%Ired(round(1+v3(2,1)),round(1+v3(1,1)))=I1(i,j);
        red = I1(i,j,1);
       green = I1(i,j,2);
        blue = I1(i,j,3);
        temp(round(1+vy),round(1+vx),1) =red;
        temp(round(1+vy),round(1+vx),2)=green;
        temp(round(1+vy),round(1+vx),3)=blue;
end
end 
end




I1=im2double(img2);
for i=1:3729
for j=1565:4992
%for d=1:3
        
    red = temp(i,j-1564,1);
    green = temp(i,j-1564,2);
    blue = temp(i,j-1564,3);
    Opimg(i,j,1)=red;
    Opimg(i,j,2)=green;
    Opimg(i,j,3)=blue;
    
   % Opimg(i,j,d) = temp(i,j-1564,d);
end

end
    %end 
%end
figure,imshow(Opimg); %final image
%figure,imshow(uint8(Opimg)); %final image


