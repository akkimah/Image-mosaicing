img1 = imread('m4.jpg');
img2 = imread('m5.jpg');
%imshow(img1);
%cpselect(img2,img1);
a=[95,557,1057,499,31,1099,1251,1219];
b=[1143,247,2397,429,909,895,2419,1473];

H=homography(a(1),a(2),a(3),a(4),a(5),a(6),a(7),a(8),b(1),b(2),b(3),b(4),b(5),b(6),b(7),b(8));
%H=homography(m4(1),m4(2},m4{3},m4{4},m4{5},m4{6},m4{7},m4{7},m5{1},m5{2},m5{3},m5{4},m5{5},m5{6},m5{7},m5{7});
h=inv(H);

Srcpoints=[1 1;1 1664;1664 1;1664 2496];
projected_point=[1 1 1] * H;
l1=projected_point(1,1)/projected_point(1,3);
m1=projected_point(1,2)/projected_point(1,3);

projected_point=[1 1664 1] * H;
l2=projected_point(1,1)/projected_point(1,3);
m2=projected_point(1,2)/projected_point(1,3);

projected_point=[1664 1 1] * H;
l3=projected_point(1,1)/projected_point(1,3);
m3=projected_point(1,2)/projected_point(1,3);

projected_point=[1664 2496 1] * H;
l4=projected_point(1,1)/projected_point(1,3);
m4=projected_point(1,2)/projected_point(1,3);

corners=[l1 m1;l2 m2;l3 m3;l4 m4];

MAX_X=corners(1,1);


for i=1:4
if MAX_X<= corners(i,1)
MAX_X=corners(i,1);
end
end

disp(MAX_X)


MAX_Y=corners(1,2);
for i=1:4
if MAX_Y<= corners(i,2)
MAX_Y=corners(i,2);
end
end

disp(MAX_Y)


MIN_X=corners(1,1);

for i=1:4
if MIN_X>= corners(i,1)
MIN_X=corners(i,1);
end
end

disp(MIN_X)

MIN_Y=corners(1,2);
for i=1:4
if MIN_Y>= corners(i,2)
MIN_Y=corners(i,2);
end
end

disp(MIN_Y)

height_max=round(MAX_Y-MIN_Y);
width_max=round(MAX_X-MIN_X);

Opimg = zeros(height_max,4992);
img1=im2double(img1);

if(MIN_X<0)
    offset_x=round(abs(MIN_X));
else
    offset_x=0;
end

if(MIN_Y<0)
    offset_y=round(abs(MIN_Y));
else
    offset_y=0;
end


for i=1:1664
    for j=1:2496
    red = img1(i,j,1);
    green = img1(i,j,2);
    blue = img1(i,j,3);
 
        Opimg(i+offset_x,j+offset_y,1)=red;
        Opimg(i+offset_x,j+offset_y,2)=green;
        Opimg(i+offset_x,j+offset_y,3)=blue;
        %Opimg(i+1768,j,d) = img1(i,j,d);
    end
 end

%I=imread('m5.jpg');
[m,n]=size(img2);
temp = zeros(height_max+1,width_max+1);
%imshow('m1.jpg');
I1=im2double(img2);
for i=1:1664
for j=1:2496
v1 = [j ,i, 1];
v2 = v1*h;
vx = v2(1,1)/v2(1,3);
vy = v2(1,2)/v2(1,3);
vx=round(vx);
vy=round(vy);
if(vx>=1 && vy>=1 && vx<=size(temp,1) && vy<=size(temp,2))

%if(v3(1,1) <0 || v3(2,1)<0 || v3(3,1)<0)
 %  continue;
%else     
%Ired(round(1+v3(2,1)),round(1+v3(1,1)))=I1(i,j);
        red = I1(i,j,1);
       green = I1(i,j,2);
        blue = I1(i,j,3);
        temp(round(1+vy),round(1+vx),1) =red;
        temp(round(1+vy),round(1+vx),2)=green;
        temp(round(1+vy),round(1+vx),3)=blue;
end
end 
end

%imshow(uint8(Opimg));
%figure,imshow(Opimg);


I1=im2double(img2);
for i=1:height_max
for j=4992-width_max:4992
%for d=1:3
        
    red = temp(i,j-(4992-width_max-1),1);
    green = temp(i,j-(4992-width_max-1),2);
    blue = temp(i,j-(4992-width_max-1),3);
    Opimg(i,j,1)=red;
    Opimg(i,j,2)=green;
    Opimg(i,j,3)=blue;
    
   % Opimg(i,j,d) = temp(i,j-1564,d);
%end

end
    %end 
end
figure,imshow(Opimg);