H=[0.000584833983883437,-0.000389757434320398,-3.34430919209875e-10;9.26818829249812e-05,0.000364768269307820,-7.62666181308973e-08;-0.751372686029558,0.659877439854720,0.000464189653357783];

h = inv(H);
I=imread('m1.jpg');
[m,n]=size(I);
temp = zeros(3729,3428);
%imshow('m1.jpg');
I1=im2double(I);
for i=1:1664
for j=1:2496
%v1 = [j ,i, 1];
v2 = [i j 1]*h;
vx = v2(1,1)/v2(1,3);
vy = v2(1,2)/v2(1,3);
vx=round(vx);
vy=round(vy);
if(vx>=1 && vy>=1 && vx<=size(I1,1) && vy<=size(I1,2))
    temp(i,j)=I1(vx,vy);
%if(v3(1,1) <0 || v3(2,1)<0 || v3(3,1)<0)
 %  continue;
%else     
%Ired(round(1+v3(2,1)),round(1+v3(1,1)))=I1(i,j);
 %       red = I1(i,j,1);
  %     blue = I1(i,j,3);
   %     temp(round(1+vy),round(1+vx),1) =red;
    %    temp(round(1+vy),round(1+vx),2)=green;
     %   temp(round(1+vy),round(1+vx),3)=blue;
end
end 
end

imshow(uint8(temp));
figure,imshow(temp);