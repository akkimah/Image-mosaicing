Xc = imread('m1.jpg');
[sizex, sizey, sizez]= size(Xc);
    blank = zeros(sizex,sizey,sizez);
    for i=1:sizex
        for j=1:sizey
            for d=1:3
                blank(i,j,d)=Xc(i,j,d);
            end
        end
    end
    
    
    imshow(uint8(blank));
    
    
    
    
    
    
    
    for i=1:1664
    for j=1:2496
        for d=1:3
        Opimg(i+1768,j+25,d) = img1(i,j,d);
        end
    end
    end

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    I1=im2double(I);
for i=1:308
i
for j=1:288
v1 = [j;i;1];
v2 = H*v1;
v3 =v2/v2(3,1);
if (v3(1,1) <0 || v3(2,1)<0 || v3(3,1)<0)
   continue;
else     
Opimg(round(1+v3(2,1)),round(1+v3(1,1)))=img1(i,j);
end
end 